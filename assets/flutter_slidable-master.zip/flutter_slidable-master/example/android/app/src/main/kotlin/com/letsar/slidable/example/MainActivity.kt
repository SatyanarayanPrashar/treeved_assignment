package com.letsar.slidable.example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
